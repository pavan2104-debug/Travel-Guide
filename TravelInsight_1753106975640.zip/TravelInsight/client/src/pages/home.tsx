import { useState } from "react";
import Header from "@/components/header";
import Footer from "@/components/footer";
import TravelSearchForm from "@/components/travel-search-form";
import TravelResults from "@/components/travel-results";
import FeaturesSection from "@/components/features-section";
import { TravelData } from "@shared/schema";

export default function Home() {
  const [travelData, setTravelData] = useState<TravelData | null>(null);
  const [userMobile, setUserMobile] = useState<string>("");

  const handleSearchResults = (data: TravelData, mobile: string) => {
    setTravelData(data);
    setUserMobile(mobile);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-brand-blue to-blue-700 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">Your Smart India Travel Companion</h2>
            <p className="text-xl md:text-2xl mb-8 text-blue-100">Get comprehensive Indian city information delivered straight to your mobile</p>
            <div className="flex justify-center items-center space-x-4 text-blue-100">
              <i className="fas fa-mobile-alt text-2xl"></i>
              <span className="text-lg">SMS • Weather • News • Hotels • Restaurants • Safety</span>
            </div>
          </div>
        </div>
      </section>

      {/* Search Form */}
      <section className="py-12 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <TravelSearchForm onResults={handleSearchResults} />
        </div>
      </section>

      {/* Results */}
      {travelData && (
        <TravelResults data={travelData} userMobile={userMobile} />
      )}

      {/* Features */}
      <FeaturesSection />
      
      <Footer />
    </div>
  );
}
