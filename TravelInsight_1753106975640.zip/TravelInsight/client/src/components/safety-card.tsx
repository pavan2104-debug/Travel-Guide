import { SafetyData } from "@shared/schema";

interface SafetyCardProps {
  safety: SafetyData;
}

export default function SafetyCard({ safety }: SafetyCardProps) {
  const getSafetyLevelColor = (level: string) => {
    switch (level.toLowerCase()) {
      case 'high':
        return 'bg-green-100 text-green-800';
      case 'moderate':
        return 'bg-yellow-100 text-yellow-800';
      case 'low':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
      <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
        <i className="fas fa-shield-alt text-brand-green mr-2"></i>Safety & Security
      </h4>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-gray-600">Safety Score</span>
          <div className="flex items-center space-x-2">
            <span className="font-semibold text-brand-amber">{safety.score}/10</span>
            <span className={`px-2 py-1 rounded-full text-xs font-medium ${getSafetyLevelColor(safety.level)}`}>
              {safety.level}
            </span>
          </div>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-gray-600">Crime Rate</span>
          <span className="font-medium text-gray-900">{safety.crimeRate}</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-gray-600">Political Events</span>
          <span className="font-medium text-gray-900">{safety.politicalEvents}</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-gray-600">Air Quality</span>
          <span className="font-medium text-gray-900">{safety.airQuality}</span>
        </div>
      </div>
    </div>
  );
}
