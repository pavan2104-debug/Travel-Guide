import { Restaurant } from "@shared/schema";

interface RestaurantsCardProps {
  restaurants: Restaurant[];
}

export default function RestaurantsCard({ restaurants }: RestaurantsCardProps) {
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push(<i key={i} className="fas fa-star text-yellow-400 text-xs"></i>);
    }
    
    if (hasHalfStar) {
      stars.push(<i key="half" className="fas fa-star-half-alt text-yellow-400 text-xs"></i>);
    }
    
    const remainingStars = 5 - Math.ceil(rating);
    for (let i = 0; i < remainingStars; i++) {
      stars.push(<i key={`empty-${i}`} className="far fa-star text-yellow-400 text-xs"></i>);
    }
    
    return stars;
  };

  return (
    <div className="mt-8">
      <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
        <h4 className="text-lg font-semibold text-gray-900 mb-6 flex items-center">
          <i className="fas fa-utensils text-brand-green mr-2"></i>Top Restaurants
        </h4>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {restaurants.length === 0 ? (
            <div className="col-span-full text-center py-8">
              <p className="text-gray-500">Restaurant data not available</p>
              <p className="text-sm text-gray-400 mt-1">Check popular review sites for dining recommendations</p>
            </div>
          ) : (
            restaurants.slice(0, 6).map((restaurant, index) => (
              <div key={index} className="p-4 bg-gray-50 rounded-lg">
                <h5 className="font-medium text-gray-900 mb-1">{restaurant.name}</h5>
                <p className="text-sm text-gray-600 mb-2">{restaurant.cuisine} • {restaurant.type}</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-1">
                    {renderStars(restaurant.rating)}
                    <span className="text-xs text-gray-600 ml-1">{restaurant.rating}</span>
                  </div>
                  <span className="text-sm font-medium text-gray-900">{restaurant.priceLevel}</span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
