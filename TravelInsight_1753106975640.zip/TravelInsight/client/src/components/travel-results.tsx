import { TravelData } from "@shared/schema";
import SMSPreview from "./sms-preview";
import WeatherCard from "./weather-card";
import SafetyCard from "./safety-card";
import NewsCard from "./news-card";
import HotelsCard from "./hotels-card";
import RestaurantsCard from "./restaurants-card";

interface TravelResultsProps {
  data: TravelData;
  userMobile: string;
}

export default function TravelResults({ data, userMobile }: TravelResultsProps) {
  return (
    <section className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-2">
            Travel Information for <span className="text-brand-blue">{data.city}</span>
          </h3>
          <p className="text-gray-600">Comprehensive details sent to your mobile device</p>
        </div>

        {/* SMS Preview */}
        <SMSPreview smsContent={data.smsPreview} userMobile={userMobile} />

        {/* Information Grid */}
        <div className="grid lg:grid-cols-2 gap-8">
          <WeatherCard weather={data.weather} />
          <SafetyCard safety={data.safety} />
          <NewsCard news={data.news} />
          <HotelsCard hotels={data.hotels} />
        </div>

        {/* Restaurants Section */}
        <RestaurantsCard restaurants={data.restaurants} />
      </div>
    </section>
  );
}
