import { WeatherData } from "@shared/schema";

interface WeatherCardProps {
  weather: WeatherData;
}

export default function WeatherCard({ weather }: WeatherCardProps) {
  return (
    <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
      <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
        <i className="fas fa-cloud-sun text-brand-amber mr-2"></i>Weather & Climate
      </h4>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-gray-600">Current Temperature</span>
          <span className="font-semibold text-2xl text-gray-900">{weather.temperature}°C</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-gray-600">Condition</span>
          <span className="font-medium text-gray-900">{weather.condition}</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-gray-600">Humidity</span>
          <span className="font-medium text-gray-900">{weather.humidity}%</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-gray-600">Wind Speed</span>
          <span className="font-medium text-gray-900">{weather.windSpeed} km/h</span>
        </div>
        {weather.description && (
          <div className="flex items-center justify-between">
            <span className="text-gray-600">Description</span>
            <span className="font-medium text-gray-900 capitalize">{weather.description}</span>
          </div>
        )}
      </div>
    </div>
  );
}
