import { Hotel } from "@shared/schema";

interface HotelsCardProps {
  hotels: Hotel[];
}

export default function HotelsCard({ hotels }: HotelsCardProps) {
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push(<i key={i} className="fas fa-star text-yellow-400 text-xs"></i>);
    }
    
    if (hasHalfStar) {
      stars.push(<i key="half" className="fas fa-star-half-alt text-yellow-400 text-xs"></i>);
    }
    
    const remainingStars = 5 - Math.ceil(rating);
    for (let i = 0; i < remainingStars; i++) {
      stars.push(<i key={`empty-${i}`} className="far fa-star text-yellow-400 text-xs"></i>);
    }
    
    return stars;
  };

  return (
    <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
      <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
        <i className="fas fa-bed text-brand-blue mr-2"></i>Top Hotels
      </h4>
      <div className="space-y-4">
        {hotels.length === 0 ? (
          <div className="text-center py-4">
            <p className="text-gray-500">Hotel data not available</p>
            <p className="text-sm text-gray-400 mt-1">Check popular booking sites for accommodations</p>
          </div>
        ) : (
          hotels.slice(0, 3).map((hotel, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex-1">
                <h5 className="font-medium text-gray-900">{hotel.name}</h5>
                <p className="text-sm text-gray-600">{hotel.type} • {hotel.location}</p>
                <div className="flex items-center space-x-1 mt-1">
                  {renderStars(hotel.rating)}
                  <span className="text-xs text-gray-600 ml-1">{hotel.rating}</span>
                </div>
              </div>
              <div className="text-right">
                <span className="text-lg font-semibold text-gray-900">₹{hotel.price}</span>
                <p className="text-sm text-gray-600">per night</p>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
