import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { insertTravelRequestSchema, type TravelData } from "@shared/schema";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

const formSchema = insertTravelRequestSchema.extend({
  mobile: z.string().min(10, "Please enter a valid Indian mobile number"),
  city: z.string().min(2, "Please enter a valid Indian city name"),
});

type FormData = z.infer<typeof formSchema>;

interface TravelSearchFormProps {
  onResults: (data: TravelData, mobile: string) => void;
}

export default function TravelSearchForm({ onResults }: TravelSearchFormProps) {
  const { toast } = useToast();
  
  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      mobile: "",
      city: "",
      country: "",
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: FormData) => {
      const response = await apiRequest("POST", "/api/travel/search", data);
      return response.json();
    },
    onSuccess: (result) => {
      if (result.success) {
        onResults(result.data, form.getValues("mobile"));
        toast({
          title: "Travel information retrieved!",
          description: "SMS sent to your mobile number with summary.",
        });
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to retrieve travel information",
          variant: "destructive",
        });
      }
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to retrieve travel information. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FormData) => {
    mutation.mutate(data);
  };

  const formatMobileNumber = (value: string) => {
    const cleaned = value.replace(/\D/g, '');
    
    // Handle Indian mobile numbers (+91 format)
    if (cleaned.length === 0) return '';
    if (cleaned.length <= 2) {
      return cleaned.startsWith('91') ? `+91 ${cleaned.slice(2)}` : `+91 ${cleaned}`;
    } else if (cleaned.length <= 5) {
      return `+91 ${cleaned.slice(2) || cleaned}`;
    } else if (cleaned.length <= 8) {
      const number = cleaned.startsWith('91') ? cleaned.slice(2) : cleaned;
      return `+91 ${number.slice(0, 5)} ${number.slice(5)}`;
    } else {
      const number = cleaned.startsWith('91') ? cleaned.slice(2) : cleaned;
      return `+91 ${number.slice(0, 5)} ${number.slice(5, 10)}`;
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8">
      <div className="text-center mb-8">
        <h3 className="text-2xl font-bold text-gray-900 mb-2">Plan Your Indian City Trip</h3>
        <p className="text-gray-600">Enter your mobile number and destination city to receive comprehensive travel information via SMS</p>
      </div>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="mobile"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center text-sm font-medium text-gray-700">
                    <i className="fas fa-mobile-alt text-brand-blue mr-2"></i>
                    Mobile Number
                  </FormLabel>
                  <FormControl>
                    <Input
                      type="tel"
                      placeholder="+91 98765 43210"
                      {...field}
                      onChange={(e) => {
                        const formatted = formatMobileNumber(e.target.value);
                        field.onChange(formatted);
                      }}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-blue focus:border-transparent transition-colors"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="city"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center text-sm font-medium text-gray-700">
                    <i className="fas fa-map-marker-alt text-brand-blue mr-2"></i>
                    Destination City
                  </FormLabel>
                  <FormControl>
                    <Input
                      type="text"
                      placeholder="e.g., Mumbai, Delhi, Bangalore, Chennai"
                      {...field}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-blue focus:border-transparent transition-colors"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          <div className="flex justify-center">
            <Button
              type="submit"
              disabled={mutation.isPending}
              className="bg-brand-blue text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors flex items-center space-x-2"
            >
              {mutation.isPending ? (
                <>
                  <i className="fas fa-spinner fa-spin"></i>
                  <span>Processing...</span>
                </>
              ) : (
                <>
                  <i className="fas fa-search"></i>
                  <span>Get Travel Information</span>
                </>
              )}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}
