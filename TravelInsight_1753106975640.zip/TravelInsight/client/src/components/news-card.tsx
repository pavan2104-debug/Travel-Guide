import { NewsArticle } from "@shared/schema";

interface NewsCardProps {
  news: NewsArticle[];
}

export default function NewsCard({ news }: NewsCardProps) {
  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return "Less than an hour ago";
    if (diffInHours < 24) return `${diffInHours} hour${diffInHours > 1 ? 's' : ''} ago`;
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays} day${diffInDays > 1 ? 's' : ''} ago`;
  };

  return (
    <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
      <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
        <i className="fas fa-newspaper text-brand-blue mr-2"></i>Latest News & Events
      </h4>
      <div className="space-y-4">
        {news.length === 0 ? (
          <div className="text-center py-4">
            <p className="text-gray-500">No recent news available for this location</p>
          </div>
        ) : (
          news.map((article, index) => (
            <div key={index} className="border-b border-gray-200 pb-3 last:border-b-0">
              <h5 className="font-medium text-gray-900 mb-1">
                {article.url !== "#" ? (
                  <a href={article.url} target="_blank" rel="noopener noreferrer" className="hover:text-brand-blue transition-colors">
                    {article.title}
                  </a>
                ) : (
                  article.title
                )}
              </h5>
              {article.description && (
                <p className="text-sm text-gray-600 mb-2">{article.description}</p>
              )}
              <span className="text-xs text-gray-500">{formatTimeAgo(article.publishedAt)}</span>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
