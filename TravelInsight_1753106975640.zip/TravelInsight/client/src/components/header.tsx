export default function Header() {
  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center space-x-3">
            <i className="fas fa-plane text-brand-blue text-2xl"></i>
            <h1 className="text-2xl font-bold text-gray-900">Travel Way</h1>
          </div>
          <nav className="hidden md:flex space-x-8">
            <a href="#" className="text-gray-700 hover:text-brand-blue transition-colors">Home</a>
            <a href="#" className="text-gray-700 hover:text-brand-blue transition-colors">About</a>
            <a href="#" className="text-gray-700 hover:text-brand-blue transition-colors">Contact</a>
          </nav>
          <button className="md:hidden text-gray-600">
            <i className="fas fa-bars text-xl"></i>
          </button>
        </div>
      </div>
    </header>
  );
}
