export default function FeaturesSection() {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h3 className="text-3xl font-bold text-gray-900 mb-4">Why Choose Travel Way?</h3>
          <p className="text-xl text-gray-600">Everything you need to know about your destination, delivered instantly</p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          <div className="text-center p-6">
            <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-mobile-alt text-brand-blue text-2xl"></i>
            </div>
            <h4 className="text-xl font-semibold text-gray-900 mb-2">SMS Delivery</h4>
            <p className="text-gray-600">Get essential travel information sent directly to your phone via SMS</p>
          </div>
          
          <div className="text-center p-6">
            <div className="bg-green-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-clock text-brand-green text-2xl"></i>
            </div>
            <h4 className="text-xl font-semibold text-gray-900 mb-2">Real-Time Updates</h4>
            <p className="text-gray-600">Stay informed with live weather, news, and safety alerts for your destination</p>
          </div>
          
          <div className="text-center p-6">
            <div className="bg-amber-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-shield-alt text-brand-amber text-2xl"></i>
            </div>
            <h4 className="text-xl font-semibold text-gray-900 mb-2">Safety First</h4>
            <p className="text-gray-600">Comprehensive safety scores and political event monitoring for peace of mind</p>
          </div>
          
          <div className="text-center p-6">
            <div className="bg-purple-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-hotel text-purple-600 text-2xl"></i>
            </div>
            <h4 className="text-xl font-semibold text-gray-900 mb-2">Hotel Recommendations</h4>
            <p className="text-gray-600">Curated hotel suggestions with ratings and pricing information</p>
          </div>
          
          <div className="text-center p-6">
            <div className="bg-red-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-utensils text-brand-red text-2xl"></i>
            </div>
            <h4 className="text-xl font-semibold text-gray-900 mb-2">Dining Guide</h4>
            <p className="text-gray-600">Top-rated restaurants and local dining recommendations</p>
          </div>
          
          <div className="text-center p-6">
            <div className="bg-indigo-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-newspaper text-indigo-600 text-2xl"></i>
            </div>
            <h4 className="text-xl font-semibold text-gray-900 mb-2">Local News</h4>
            <p className="text-gray-600">Stay updated with current events and happenings in your destination</p>
          </div>
        </div>
      </div>
    </section>
  );
}
