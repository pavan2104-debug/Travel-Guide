interface SMSPreviewProps {
  smsContent: string;
  userMobile: string;
}

export default function SMSPreview({ smsContent, userMobile }: SMSPreviewProps) {
  return (
    <div className="mb-8">
      <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h4 className="text-lg font-semibold text-gray-900 flex items-center">
            <i className="fas fa-sms text-brand-blue mr-2"></i>SMS Preview
          </h4>
          <span className="text-sm text-gray-500">Sent to {userMobile}</span>
        </div>
        <div className="bg-gray-50 rounded-lg p-4 text-sm text-gray-700 font-mono whitespace-pre-line">
          {smsContent}
        </div>
      </div>
    </div>
  );
}
