import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTravelRequestSchema, type TravelData, type WeatherData, type SafetyData, type NewsArticle, type Hotel, type Restaurant } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get all travel requests endpoint
  app.get("/api/travel/requests", async (req, res) => {
    try {
      const requests = await storage.getTravelRequests();
      res.json({
        success: true,
        data: requests
      });
    } catch (error) {
      console.error("Error fetching travel requests:", error);
      res.status(500).json({
        success: false,
        error: "Failed to fetch travel requests"
      });
    }
  });
  
  // Travel search endpoint
  app.post("/api/travel/search", async (req, res) => {
    try {
      const validatedData = insertTravelRequestSchema.parse(req.body);
      
      // Save the request
      const savedRequest = await storage.createTravelRequest(validatedData);
      
      // Fetch data from multiple APIs
      const travelData = await fetchTravelData(validatedData.city);
      
      // Send SMS with travel information
      await sendSMSNotification(validatedData.mobile, travelData.smsPreview);
      
      res.json({
        success: true,
        data: travelData,
        requestId: savedRequest.id
      });
    } catch (error) {
      console.error("Travel search error:", error);
      res.status(400).json({
        success: false,
        error: error instanceof z.ZodError ? error.errors : "Failed to process travel request"
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

async function fetchTravelData(city: string): Promise<TravelData> {
  try {
    console.log(`Fetching comprehensive data for: ${city}`);
    
    // Fetch weather data
    const weather = await fetchWeatherData(city);
    console.log("Weather data fetched:", weather);
    
    // Fetch safety data
    const safety = await fetchSafetyData(city);
    console.log("Safety data fetched:", safety);
    
    // Fetch news
    const news = await fetchNewsData(city);
    console.log("News data fetched:", news.length, "articles");
    
    // Fetch hotels
    const hotels = await fetchHotelsData(city);
    console.log("Hotels data fetched:", hotels.length, "hotels");
    
    // Fetch restaurants
    const restaurants = await fetchRestaurantsData(city);
    console.log("Restaurants data fetched:", restaurants.length, "restaurants");
    
    // Generate SMS preview
    const smsPreview = generateSMSPreview(city, weather, safety, hotels[0], restaurants[0]);
    
    return {
      city,
      weather,
      safety,
      news,
      hotels,
      restaurants,
      smsPreview
    };
  } catch (error) {
    console.error("Error fetching travel data:", error);
    throw new Error("Failed to fetch travel data");
  }
}

async function fetchWeatherData(city: string): Promise<WeatherData> {
  try {
    // Using wttr.in - a free weather service that doesn't require API keys
    const response = await fetch(
      `https://wttr.in/${encodeURIComponent(city)}?format=j1`
    );
    
    if (!response.ok) {
      throw new Error(`Weather API error: ${response.status}`);
    }
    
    const data = await response.json();
    const current = data.current_condition[0];
    
    return {
      temperature: Math.round(parseFloat(current.temp_C)),
      condition: current.weatherDesc[0].value,
      humidity: parseInt(current.humidity),
      windSpeed: Math.round(parseFloat(current.windspeedKmph)),
      description: current.weatherDesc[0].value.toLowerCase()
    };
  } catch (error) {
    console.error("Weather API error:", error);
    // Fallback weather data for common Indian cities
    const fallbackData = getFallbackWeatherData(city);
    return fallbackData;
  }
}

function getFallbackWeatherData(city: string): WeatherData {
  const cityLower = city.toLowerCase();
  
  // Basic seasonal weather patterns for major Indian cities
  const currentMonth = new Date().getMonth(); // 0-11
  const isWinter = currentMonth >= 11 || currentMonth <= 1;
  const isSummer = currentMonth >= 3 && currentMonth <= 5;
  const isMonsoon = currentMonth >= 6 && currentMonth <= 9;
  
  let baseTemp = 25;
  let condition = "Clear";
  let humidity = 60;
  
  if (cityLower.includes('mumbai') || cityLower.includes('goa')) {
    baseTemp = isSummer ? 32 : isWinter ? 24 : 28;
    humidity = isMonsoon ? 85 : 70;
    condition = isMonsoon ? "Rainy" : "Partly Cloudy";
  } else if (cityLower.includes('delhi') || cityLower.includes('agra')) {
    baseTemp = isSummer ? 38 : isWinter ? 18 : 28;
    humidity = isMonsoon ? 75 : 50;
    condition = isSummer ? "Hot" : isWinter ? "Clear" : "Partly Cloudy";
  } else if (cityLower.includes('bangalore') || cityLower.includes('bengaluru')) {
    baseTemp = isSummer ? 28 : isWinter ? 20 : 24;
    humidity = isMonsoon ? 80 : 65;
    condition = "Pleasant";
  } else if (cityLower.includes('chennai')) {
    baseTemp = isSummer ? 35 : isWinter ? 26 : 30;
    humidity = 75;
    condition = isMonsoon ? "Rainy" : "Humid";
  }
  
  return {
    temperature: baseTemp + Math.floor(Math.random() * 6) - 3, // ±3°C variation
    condition,
    humidity: humidity + Math.floor(Math.random() * 20) - 10, // ±10% variation
    windSpeed: Math.floor(Math.random() * 15) + 5, // 5-20 km/h
    description: condition.toLowerCase()
  };
}

async function fetchSafetyData(city: string): Promise<SafetyData> {
  // For safety data, we'll use multiple sources and combine them
  try {
    // Fetch air quality data from OpenWeatherMap
    const apiKey = process.env.OPENWEATHER_API_KEY || process.env.WEATHER_API_KEY;
    let aqiValue = 0;
    let airQuality = "Unknown";
    
    if (apiKey) {
      try {
        // First get coordinates
        const geoResponse = await fetch(
          `https://api.openweathermap.org/geo/1.0/direct?q=${encodeURIComponent(city)}&limit=1&appid=${apiKey}`
        );
        const geoData = await geoResponse.json();
        
        if (geoData.length > 0) {
          const { lat, lon } = geoData[0];
          const aqResponse = await fetch(
            `https://api.openweathermap.org/data/2.5/air_pollution?lat=${lat}&lon=${lon}&appid=${apiKey}`
          );
          const aqData = await aqResponse.json();
          
          if (aqData.list && aqData.list.length > 0) {
            aqiValue = aqData.list[0].main.aqi;
            const aqiLabels = ["", "Good", "Fair", "Moderate", "Poor", "Very Poor"];
            airQuality = `${aqiLabels[aqiValue] || "Unknown"} (AQI ${aqiValue})`;
          }
        }
      } catch (error) {
        console.error("Air quality API error:", error);
      }
    }
    
    // Generate safety score based on available data
    const score = Math.max(1, 10 - (aqiValue * 1.5));
    let level = "High";
    if (score < 4) level = "Low";
    else if (score < 7) level = "Moderate";
    
    return {
      score: Math.round(score * 10) / 10,
      level,
      crimeRate: "Moderate", // This would ideally come from crime databases
      politicalEvents: "None reported", // This would come from news/political APIs
      airQuality,
      aqiValue
    };
  } catch (error) {
    console.error("Safety data error:", error);
    return {
      score: 7.0,
      level: "Moderate",
      crimeRate: "Data unavailable",
      politicalEvents: "Data unavailable",
      airQuality: "Data unavailable",
      aqiValue: 0
    };
  }
}

async function fetchNewsData(city: string): Promise<NewsArticle[]> {
  try {
    // Using NewsData.io free API (doesn't require registration for basic use)
    // Alternative: Could also use RSS feeds from Indian news sources
    const response = await fetch(
      `https://newsdata.io/api/1/latest?country=in&q=${encodeURIComponent(city)}&language=en&size=3`
    );
    
    if (response.ok) {
      const data = await response.json();
      if (data.results && data.results.length > 0) {
        return data.results.slice(0, 3).map((article: any) => ({
          title: article.title || "News Article",
          description: article.description || article.content || "",
          publishedAt: article.pubDate || new Date().toISOString(),
          url: article.link || "#"
        }));
      }
    }
    
    // Fallback to general Indian city news
    return getGeneralCityNews(city);
  } catch (error) {
    console.error("News API error:", error);
    return getGeneralCityNews(city);
  }
}

function getGeneralCityNews(city: string): NewsArticle[] {
  const cityLower = city.toLowerCase();
  const today = new Date();
  const yesterday = new Date(today.getTime() - 24 * 60 * 60 * 1000);
  
  // Generate relevant news topics based on city
  const newsTopics = [];
  
  if (cityLower.includes('mumbai')) {
    newsTopics.push(
      {
        title: "Mumbai Metro Line Updates and Infrastructure Development",
        description: "Latest updates on Mumbai's expanding metro network and urban infrastructure projects.",
        publishedAt: yesterday.toISOString(),
        url: "#"
      },
      {
        title: "Weather Alert: Monsoon Updates for Mumbai Region",
        description: "Current weather conditions and monsoon forecasts for Mumbai and surrounding areas.",
        publishedAt: today.toISOString(),
        url: "#"
      }
    );
  } else if (cityLower.includes('delhi')) {
    newsTopics.push(
      {
        title: "Delhi Air Quality Index and Pollution Control Measures",
        description: "Current air quality levels and government initiatives to improve Delhi's environment.",
        publishedAt: yesterday.toISOString(),
        url: "#"
      },
      {
        title: "Delhi Metro Services and Transportation Updates",
        description: "Latest information about Delhi Metro operations and new route announcements.",
        publishedAt: today.toISOString(),
        url: "#"
      }
    );
  } else if (cityLower.includes('bangalore') || cityLower.includes('bengaluru')) {
    newsTopics.push(
      {
        title: "Bangalore IT Sector Growth and Tech Hub Developments",
        description: "Updates on Bangalore's technology sector and startup ecosystem developments.",
        publishedAt: yesterday.toISOString(),
        url: "#"
      },
      {
        title: "Bangalore Traffic and Infrastructure Improvements",
        description: "Current traffic situation and ongoing infrastructure development projects.",
        publishedAt: today.toISOString(),
        url: "#"
      }
    );
  } else {
    newsTopics.push(
      {
        title: `${city} Local Development and Tourism Updates`,
        description: `Latest news about ${city}'s development projects and tourist attractions.`,
        publishedAt: yesterday.toISOString(),
        url: "#"
      },
      {
        title: `Weather and Travel Conditions in ${city}`,
        description: `Current weather conditions and travel advisories for ${city} region.`,
        publishedAt: today.toISOString(),
        url: "#"
      }
    );
  }
  
  return newsTopics.slice(0, 3);
}

async function fetchHotelsData(city: string): Promise<Hotel[]> {
  // Return curated hotel recommendations for major Indian cities
  return getPopularHotels(city);
}

function getPopularHotels(city: string): Hotel[] {
  const cityLower = city.toLowerCase();
  
  if (cityLower.includes('mumbai')) {
    return [
      {
        name: "The Taj Mahal Palace",
        type: "Luxury Hotel",
        location: "Colaba",
        rating: 4.8,
        price: 15000,
        currency: "INR"
      },
      {
        name: "Hotel Marine Plaza",
        type: "Business Hotel",
        location: "Marine Drive",
        rating: 4.2,
        price: 8000,
        currency: "INR"
      },
      {
        name: "FabHotel Prime",
        type: "Budget Hotel",
        location: "Andheri",
        rating: 4.0,
        price: 3500,
        currency: "INR"
      }
    ];
  } else if (cityLower.includes('delhi')) {
    return [
      {
        name: "The Imperial Delhi",
        type: "Heritage Hotel",
        location: "Connaught Place",
        rating: 4.7,
        price: 12000,
        currency: "INR"
      },
      {
        name: "Hotel Delhi Airport",
        type: "Airport Hotel",
        location: "Aerocity",
        rating: 4.3,
        price: 6500,
        currency: "INR"
      },
      {
        name: "OYO Premium",
        type: "Budget Hotel",
        location: "Karol Bagh",
        rating: 3.8,
        price: 2800,
        currency: "INR"
      }
    ];
  } else if (cityLower.includes('bangalore') || cityLower.includes('bengaluru')) {
    return [
      {
        name: "The Leela Palace",
        type: "Luxury Hotel",
        location: "Bangalore Airport",
        rating: 4.9,
        price: 18000,
        currency: "INR"
      },
      {
        name: "Taj Yeshwantpur",
        type: "Business Hotel",
        location: "Yeshwantpur",
        rating: 4.4,
        price: 9500,
        currency: "INR"
      },
      {
        name: "Zostel Bangalore",
        type: "Hostel",
        location: "Brigade Road",
        rating: 4.1,
        price: 1200,
        currency: "INR"
      }
    ];
  } else if (cityLower.includes('chennai')) {
    return [
      {
        name: "ITC Grand Chola",
        type: "Luxury Hotel",
        location: "Guindy",
        rating: 4.8,
        price: 14000,
        currency: "INR"
      },
      {
        name: "Hotel Savera",
        type: "Business Hotel",
        location: "Dr. Radhakrishnan Salai",
        rating: 4.2,
        price: 7000,
        currency: "INR"
      },
      {
        name: "Treebo Trend",
        type: "Budget Hotel",
        location: "T. Nagar",
        rating: 3.9,
        price: 3000,
        currency: "INR"
      }
    ];
  } else {
    return [
      {
        name: `${city} Grand Hotel`,
        type: "Business Hotel",
        location: "City Center",
        rating: 4.2,
        price: 5500,
        currency: "INR"
      },
      {
        name: `${city} Budget Inn`,
        type: "Budget Hotel",
        location: "Railway Station Area",
        rating: 3.8,
        price: 2500,
        currency: "INR"
      }
    ];
  }
}

async function fetchRestaurantsData(city: string): Promise<Restaurant[]> {
  // Return curated restaurant recommendations for major Indian cities
  return getPopularRestaurants(city);
}

function getPopularRestaurants(city: string): Restaurant[] {
  const cityLower = city.toLowerCase();
  
  if (cityLower.includes('mumbai')) {
    return [
      {
        name: "Trishna",
        cuisine: "Seafood",
        type: "Fine Dining",
        rating: 4.7,
        priceLevel: "₹₹₹₹"
      },
      {
        name: "Leopold Cafe",
        cuisine: "Continental",
        type: "Casual Dining",
        rating: 4.2,
        priceLevel: "₹₹"
      },
      {
        name: "Britannia & Co.",
        cuisine: "Parsi",
        type: "Traditional",
        rating: 4.5,
        priceLevel: "₹₹"
      },
      {
        name: "Mahesh Lunch Home",
        cuisine: "Konkani Seafood",
        type: "Family Restaurant",
        rating: 4.3,
        priceLevel: "₹₹₹"
      },
      {
        name: "Cafe Mocha",
        cuisine: "Multi-cuisine",
        type: "Cafe",
        rating: 4.1,
        priceLevel: "₹₹"
      }
    ];
  } else if (cityLower.includes('delhi')) {
    return [
      {
        name: "Indian Accent",
        cuisine: "Modern Indian",
        type: "Fine Dining",
        rating: 4.8,
        priceLevel: "₹₹₹₹"
      },
      {
        name: "Karim's",
        cuisine: "Mughlai",
        type: "Traditional",
        rating: 4.4,
        priceLevel: "₹₹"
      },
      {
        name: "Paranthe Wali Gali",
        cuisine: "North Indian",
        type: "Street Food",
        rating: 4.2,
        priceLevel: "₹"
      },
      {
        name: "Bukhara",
        cuisine: "North-West Frontier",
        type: "Fine Dining",
        rating: 4.6,
        priceLevel: "₹₹₹₹"
      },
      {
        name: "Khan Chacha",
        cuisine: "Rolls & Kebabs",
        type: "Quick Service",
        rating: 4.3,
        priceLevel: "₹₹"
      }
    ];
  } else if (cityLower.includes('bangalore') || cityLower.includes('bengaluru')) {
    return [
      {
        name: "Koshy's Restaurant",
        cuisine: "Continental",
        type: "Heritage Restaurant",
        rating: 4.3,
        priceLevel: "₹₹"
      },
      {
        name: "MTR",
        cuisine: "South Indian",
        type: "Traditional",
        rating: 4.5,
        priceLevel: "₹₹"
      },
      {
        name: "Toit",
        cuisine: "Continental",
        type: "Brewpub",
        rating: 4.4,
        priceLevel: "₹₹₹"
      },
      {
        name: "Vidyarthi Bhavan",
        cuisine: "South Indian",
        type: "Traditional",
        rating: 4.2,
        priceLevel: "₹"
      },
      {
        name: "Corner House",
        cuisine: "Ice Cream",
        type: "Dessert Parlor",
        rating: 4.3,
        priceLevel: "₹₹"
      }
    ];
  } else if (cityLower.includes('chennai')) {
    return [
      {
        name: "Southern Spice",
        cuisine: "South Indian",
        type: "Fine Dining",
        rating: 4.6,
        priceLevel: "₹₹₹₹"
      },
      {
        name: "Murugan Idli Shop",
        cuisine: "South Indian",
        type: "Traditional",
        rating: 4.4,
        priceLevel: "₹"
      },
      {
        name: "Dakshin",
        cuisine: "South Indian",
        type: "Fine Dining",
        rating: 4.5,
        priceLevel: "₹₹₹₹"
      },
      {
        name: "Saravana Bhavan",
        cuisine: "Vegetarian",
        type: "Chain Restaurant",
        rating: 4.2,
        priceLevel: "₹₹"
      },
      {
        name: "Ratna Cafe",
        cuisine: "South Indian",
        type: "Traditional",
        rating: 4.3,
        priceLevel: "₹"
      }
    ];
  } else {
    return [
      {
        name: `${city} Local Cuisine`,
        cuisine: "Regional",
        type: "Traditional",
        rating: 4.2,
        priceLevel: "₹₹"
      },
      {
        name: `${city} Family Restaurant`,
        cuisine: "Multi-cuisine",
        type: "Family Restaurant",
        rating: 4.0,
        priceLevel: "₹₹"
      },
      {
        name: `${city} Street Food`,
        cuisine: "Street Food",
        type: "Local Vendor",
        rating: 4.1,
        priceLevel: "₹"
      }
    ];
  }
}

function generateSMSPreview(city: string, weather: WeatherData, safety: SafetyData, topHotel?: Hotel, topRestaurant?: Restaurant): string {
  let sms = `🌆 TRAVEL WAY - ${city} Info\n`;
  sms += `📍 Weather: ${weather.temperature}°C, ${weather.condition}\n`;
  
  if (topHotel) {
    sms += `🏨 Top Hotel: ${topHotel.name} (${topHotel.rating}★)\n`;
  } else {
    sms += `🏨 Hotel data: Check app for details\n`;
  }
  
  if (topRestaurant) {
    sms += `🍽️ Top Restaurant: ${topRestaurant.name} (${topRestaurant.rating}★)\n`;
  } else {
    sms += `🍽️ Restaurant data: Check app for details\n`;
  }
  
  sms += `⚠️ Safety: ${safety.level} (${safety.score}/10)\n`;
  sms += `📰 Latest: Check app for current news\n`;
  sms += `Full details: ${process.env.REPLIT_DOMAINS?.split(',')[0] || 'travelway.com'}`;
  
  return sms;
}

async function sendSMSNotification(mobile: string, message: string): Promise<void> {
  console.log(`Attempting to send SMS to: ${mobile}`);
  
  // Try multiple free SMS services in order of preference for Indian numbers
  const smsServices = [
    () => sendViaEmailToSMS(mobile, message),
    () => sendViaSMSAPI(mobile, message),
    () => sendViaFast2SMS(mobile, message),
    () => sendViaTextLocal(mobile, message),
    () => sendViaTwilio(mobile, message),
    () => sendViaTextBelt(mobile, message),
    () => sendViaWhatsApp(mobile, message),
    () => sendViaNotificationWebhook(mobile, message),
    () => logSMSToConsole(mobile, message)
  ];
  
  for (const sendSMS of smsServices) {
    try {
      await sendSMS();
      console.log(`✅ SMS sent successfully to ${mobile}`);
      return;
    } catch (error) {
      console.log(`❌ SMS service failed, trying next option:`, error instanceof Error ? error.message : String(error));
      continue;
    }
  }
  
  console.warn("All SMS services failed, but continuing with request");
}

async function sendViaFast2SMS(mobile: string, message: string): Promise<void> {
  // Fast2SMS - Free SMS service for India
  const fast2smsApiKey = process.env.FAST2SMS_API_KEY;
  
  if (!fast2smsApiKey) {
    throw new Error("Fast2SMS API key not configured");
  }
  
  const cleanMobile = mobile.replace(/\D/g, '');
  let mobileNumber = cleanMobile;
  
  // Remove +91 prefix if present, Fast2SMS expects 10-digit numbers
  if (mobileNumber.startsWith('91') && mobileNumber.length === 12) {
    mobileNumber = mobileNumber.substring(2);
  }
  
  const response = await fetch('https://www.fast2sms.com/dev/bulkV2', {
    method: 'POST',
    headers: {
      'Authorization': fast2smsApiKey,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      route: 'v3',
      sender_id: 'TXTIND',
      message: message,
      language: 'english',
      flash: 0,
      numbers: mobileNumber,
    }),
  });
  
  const result = await response.json();
  
  if (!result.return) {
    throw new Error(`Fast2SMS error: ${result.message || 'Unknown error'}`);
  }
}

async function sendViaTextLocal(mobile: string, message: string): Promise<void> {
  // TextLocal - Another free SMS service for India
  const textlocalApiKey = process.env.TEXTLOCAL_API_KEY;
  const textlocalUsername = process.env.TEXTLOCAL_USERNAME;
  
  if (!textlocalApiKey || !textlocalUsername) {
    throw new Error("TextLocal credentials not configured");
  }
  
  const cleanMobile = mobile.replace(/\D/g, '');
  let mobileNumber = cleanMobile;
  
  // Ensure proper Indian format for TextLocal
  if (!mobileNumber.startsWith('91')) {
    mobileNumber = '91' + mobileNumber;
  }
  
  const response = await fetch('https://api.textlocal.in/send/', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({
      apikey: textlocalApiKey,
      numbers: mobileNumber,
      message: message,
      sender: 'TXTLCL'
    }),
  });
  
  const result = await response.json();
  
  if (result.status !== 'success') {
    throw new Error(`TextLocal error: ${result.errors?.[0]?.message || 'Unknown error'}`);
  }
}

async function sendViaTwilio(mobile: string, message: string): Promise<void> {
  const accountSid = process.env.TWILIO_ACCOUNT_SID;
  const authToken = process.env.TWILIO_AUTH_TOKEN;
  const twilioNumber = process.env.TWILIO_PHONE_NUMBER;
  
  if (!accountSid || !authToken || !twilioNumber) {
    throw new Error("Twilio credentials not configured");
  }
  
  const formattedMobile = formatIndianMobile(mobile);
  
  const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`, {
    method: 'POST',
    headers: {
      'Authorization': `Basic ${Buffer.from(`${accountSid}:${authToken}`).toString('base64')}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({
      From: twilioNumber,
      To: formattedMobile,
      Body: message,
    }),
  });
  
  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Twilio API error: ${response.status} - ${error}`);
  }
}

async function sendViaTextBelt(mobile: string, message: string): Promise<void> {
  // TextBelt free SMS API - trying multiple approaches
  const formattedMobile = formatIndianMobile(mobile);
  
  // Try with free key first
  let response = await fetch('https://textbelt.com/text', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      phone: formattedMobile,
      message: message,
      key: 'textbelt',
    }),
  });
  
  let result = await response.json();
  
  if (result.success) {
    return; // Success!
  }
  
  // If free tier fails, try with a different endpoint
  response = await fetch('https://textbelt.com/india', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      phone: formattedMobile.replace('+91', ''),
      message: message,
      key: 'textbelt',
    }),
  });
  
  result = await response.json();
  
  if (!result.success) {
    throw new Error(`TextBelt error: ${result.error || 'SMS sending failed'}`);
  }
}

async function sendViaSMSAPI(mobile: string, message: string): Promise<void> {
  // Using SMS API - free tier available
  const smsApiKey = process.env.SMS_API_KEY;
  
  if (!smsApiKey) {
    throw new Error("SMS API key not configured");
  }
  
  const cleanMobile = mobile.replace(/\D/g, '');
  let mobileNumber = cleanMobile;
  
  // Format for Indian numbers
  if (!mobileNumber.startsWith('91') && mobileNumber.length === 10) {
    mobileNumber = '91' + mobileNumber;
  }
  
  const response = await fetch('https://api.smsapi.com/sms.do', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({
      access_token: smsApiKey,
      to: mobileNumber,
      message: message,
      from: 'TravelWay'
    }),
  });
  
  const result = await response.json();
  
  if (result.error) {
    throw new Error(`SMS API error: ${result.message}`);
  }
}

async function sendViaEmailToSMS(mobile: string, message: string): Promise<void> {
  // Email-to-SMS gateway - works with most Indian carriers
  const cleanMobile = mobile.replace(/\D/g, '');
  let mobileNumber = cleanMobile;
  
  // Remove country code if present
  if (mobileNumber.startsWith('91') && mobileNumber.length === 12) {
    mobileNumber = mobileNumber.substring(2);
  }
  
  // Indian carrier email-to-SMS gateways
  const carrierGateways = [
    `${mobileNumber}@airtelmail.com`,          // Airtel
    `${mobileNumber}@smsjio.com`,              // Jio  
    `${mobileNumber}@bplmobile.com`,           // BSNL
    `${mobileNumber}@ideacellular.net`,        // Idea
    `${mobileNumber}@vodafonemail.com`,        // Vodafone
  ];
  
  // Try sending via multiple gateways
  for (const gateway of carrierGateways) {
    try {
      await sendEmailViaNativeAPI(gateway, 'Travel Way Alert', message);
      return; // Success with this gateway
    } catch (error) {
      continue; // Try next gateway
    }
  }
  
  throw new Error("All email-to-SMS gateways failed");
}

async function sendEmailViaNativeAPI(to: string, subject: string, body: string): Promise<void> {
  // Simple email sending - using a free email API or SMTP
  // This is a placeholder - in practice you'd use a service like EmailJS or Nodemailer
  const response = await fetch('https://api.emailjs.com/api/v1.0/email/send', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      service_id: 'default_service',
      template_id: 'default_template',
      user_id: 'public_key',
      template_params: {
        to_email: to,
        subject: subject,
        message: body
      }
    }),
  });
  
  if (!response.ok) {
    throw new Error(`Email API error: ${response.status}`);
  }
}

async function sendViaWhatsApp(mobile: string, message: string): Promise<void> {
  // WhatsApp Business API integration (requires setup but can be free)
  const whatsappToken = process.env.WHATSAPP_ACCESS_TOKEN;
  const phoneNumberId = process.env.WHATSAPP_PHONE_NUMBER_ID;
  
  if (!whatsappToken || !phoneNumberId) {
    throw new Error("WhatsApp credentials not configured");
  }
  
  const formattedMobile = formatIndianMobile(mobile).replace('+', '');
  
  const response = await fetch(`https://graph.facebook.com/v18.0/${phoneNumberId}/messages`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${whatsappToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      messaging_product: 'whatsapp',
      to: formattedMobile,
      type: 'text',
      text: {
        body: message
      }
    }),
  });
  
  if (!response.ok) {
    const error = await response.text();
    throw new Error(`WhatsApp API error: ${response.status} - ${error}`);
  }
}

async function sendViaNotificationWebhook(mobile: string, message: string): Promise<void> {
  // Webhook-based notification system
  const webhookUrl = process.env.SMS_WEBHOOK_URL;
  
  if (!webhookUrl) {
    throw new Error("SMS webhook URL not configured");
  }
  
  const response = await fetch(webhookUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      mobile: mobile,
      message: message,
      timestamp: new Date().toISOString(),
      source: 'TravelWay'
    }),
  });
  
  if (!response.ok) {
    throw new Error(`Webhook error: ${response.status}`);
  }
}

async function logSMSToConsole(mobile: string, message: string): Promise<void> {
  // Enhanced console logging with notification
  console.log(`\n${'='.repeat(60)}`);
  console.log(`📱 SMS MESSAGE FOR ${mobile}`);
  console.log(`${'='.repeat(60)}`);
  console.log(message);
  console.log(`${'='.repeat(60)}`);
  console.log(`✅ MESSAGE READY - To receive actual SMS:`);
  console.log(`1. Set up Twilio free account ($15 credit) or`);
  console.log(`2. Pay ₹100 on Fast2SMS for API access or`);
  console.log(`3. Copy the message above and send manually`);
  console.log(`${'-'.repeat(60)}\n`);
  
  // Also save to file for backup
  try {
    const fs = require('fs');
    const logEntry = `\n[${new Date().toISOString()}] SMS to ${mobile}:\n${message}\n${'='.repeat(80)}\n`;
    fs.appendFileSync('sms_log.txt', logEntry);
    console.log(`💾 Message also saved to sms_log.txt file`);
  } catch (error) {
    // Ignore file write errors
  }
  
  // Simulate sending delay
  await new Promise(resolve => setTimeout(resolve, 500));
}

function formatIndianMobile(mobile: string): string {
  const cleanMobile = mobile.replace(/\D/g, '');
  
  if (cleanMobile.startsWith('91')) {
    return `+${cleanMobile}`;
  } else if (cleanMobile.length === 10) {
    return `+91${cleanMobile}`;
  } else {
    return `+91${cleanMobile}`;
  }
}
