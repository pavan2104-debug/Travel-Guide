import { travelRequests, type TravelRequest, type InsertTravelRequest } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  createTravelRequest(request: InsertTravelRequest): Promise<TravelRequest>;
  getTravelRequests(): Promise<TravelRequest[]>;
  getTravelRequestById(id: number): Promise<TravelRequest | undefined>;
}

export class DatabaseStorage implements IStorage {
  async createTravelRequest(insertRequest: InsertTravelRequest): Promise<TravelRequest> {
    const [request] = await db
      .insert(travelRequests)
      .values(insertRequest)
      .returning();
    return request;
  }

  async getTravelRequests(): Promise<TravelRequest[]> {
    return await db.select().from(travelRequests);
  }

  async getTravelRequestById(id: number): Promise<TravelRequest | undefined> {
    const [request] = await db
      .select()
      .from(travelRequests)
      .where(eq(travelRequests.id, id));
    return request || undefined;
  }
}

export const storage = new DatabaseStorage();
