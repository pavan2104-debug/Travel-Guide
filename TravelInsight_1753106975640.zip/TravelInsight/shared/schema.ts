import { pgTable, text, serial, integer, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const travelRequests = pgTable("travel_requests", {
  id: serial("id").primaryKey(),
  mobile: text("mobile").notNull(),
  city: text("city").notNull(),
  country: text("country"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertTravelRequestSchema = createInsertSchema(travelRequests).pick({
  mobile: true,
  city: true,
  country: true,
});

export type InsertTravelRequest = z.infer<typeof insertTravelRequestSchema>;
export type TravelRequest = typeof travelRequests.$inferSelect;

// API Response Types
export interface WeatherData {
  temperature: number;
  condition: string;
  humidity: number;
  windSpeed: number;
  description: string;
}

export interface SafetyData {
  score: number;
  level: string;
  crimeRate: string;
  politicalEvents: string;
  airQuality: string;
  aqiValue: number;
}

export interface NewsArticle {
  title: string;
  description: string;
  publishedAt: string;
  url: string;
}

export interface Hotel {
  name: string;
  type: string;
  location: string;
  rating: number;
  price: number;
  currency: string;
}

export interface Restaurant {
  name: string;
  cuisine: string;
  type: string;
  rating: number;
  priceLevel: string;
}

export interface TravelData {
  city: string;
  weather: WeatherData;
  safety: SafetyData;
  news: NewsArticle[];
  hotels: Hotel[];
  restaurants: Restaurant[];
  smsPreview: string;
}
