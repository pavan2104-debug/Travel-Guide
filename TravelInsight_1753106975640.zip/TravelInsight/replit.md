# Travel Safety Information System

## Overview

This is a full-stack web application that provides comprehensive travel information including weather data, safety analysis, news updates, hotel recommendations, and restaurant suggestions. The system is designed to deliver travel intelligence via SMS and web interface, with a focus on real-time safety monitoring and risk assessment.

## User Preferences

Preferred communication style: Simple, everyday language.
Target audience: Indian users with Indian mobile numbers and Indian cities.
Temperature units: Celsius (°C) for weather data.
Mobile format: Indian +91 format with proper validation.

## System Architecture

The application follows a modern full-stack architecture with clear separation between client and server components:

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui component library
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM configured for PostgreSQL
- **Validation**: Zod schemas for type-safe data validation
- **Storage**: Currently using in-memory storage with interface for easy database migration

## Key Components

### Data Models
- **Travel Requests**: Store user search queries with mobile number, city, and country
- **Weather Data**: Temperature, conditions, humidity, wind speed
- **Safety Data**: Risk scores, crime rates, political events, air quality metrics
- **News Articles**: Latest news and events for destinations
- **Hotel/Restaurant Data**: Recommendations with ratings and pricing

### API Integration Layer (Updated July 2025)
The system currently uses free APIs and comprehensive stock data:
- **Weather**: wttr.in (free weather service providing real-time data)
- **Hotels**: Comprehensive database of 100+ hotels across major Indian cities
- **Restaurants**: Curated restaurant recommendations for all Indian cities
- **Safety Data**: Stock safety scores and risk assessments for Indian cities
- **News**: City-specific fallback content with realistic news topics
- **SMS Services**: Multi-service fallback (Twilio, TextBelt, WhatsApp, Console logging)

### User Interface Components
- **Search Form**: Mobile number and destination input with validation
- **Results Display**: Modular cards for weather, safety, news, hotels, restaurants
- **SMS Preview**: Shows the summarized information sent to user's mobile
- **Responsive Design**: Mobile-first approach with Tailwind CSS

## Data Flow

1. **User Input**: User enters mobile number and destination city
2. **Validation**: Form data validated using Zod schemas
3. **API Orchestration**: Server fetches data from multiple external APIs
4. **Data Aggregation**: Information combined into structured response
5. **SMS Generation**: Summary content created for mobile delivery
6. **Response Delivery**: Comprehensive data returned to frontend
7. **Display**: Information presented in organized card layout

## External Dependencies

### Production Dependencies
- **UI Framework**: React, Radix UI primitives, shadcn/ui components
- **Database**: Drizzle ORM, @neondatabase/serverless
- **Validation**: Zod for schema validation
- **HTTP Client**: Built-in fetch API
- **State Management**: TanStack React Query
- **Date Handling**: date-fns library

### Development Tools
- **Build System**: Vite with TypeScript support
- **Code Quality**: TypeScript strict mode
- **Development Server**: Express with Vite middleware
- **Package Management**: npm with lockfile

## Deployment Strategy

### Build Process
- **Frontend**: Vite builds React app to `dist/public`
- **Backend**: esbuild bundles server code to `dist/index.js`
- **Assets**: Static files served from build output

### Environment Configuration
- **Database**: PostgreSQL connection via DATABASE_URL environment variable
- **API Keys**: External service credentials via environment variables
- **Development**: Hot module replacement with Vite
- **Production**: Optimized builds with code splitting

### Scalability Considerations
- **Database**: Ready for PostgreSQL with Drizzle migrations
- **Storage**: Interface-based design allows easy migration from memory to database
- **API Rate Limiting**: Structure supports implementing rate limiting for external APIs
- **Caching**: Architecture supports adding Redis or similar caching layer

The system is designed with modularity and extensibility in mind, making it easy to add new data sources, expand functionality, or migrate to different infrastructure components as needed.